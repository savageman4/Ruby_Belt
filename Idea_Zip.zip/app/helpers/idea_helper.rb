module IdeaHelper
end
