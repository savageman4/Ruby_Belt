FactoryBot.define do
  factory :user do
    name "MyText"
    email "MyText"
    password ""
  end
end
