FactoryBot.define do
  factory :idea do
    content "MyText"
    user nil
  end
end
