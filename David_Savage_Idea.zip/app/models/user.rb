class User < ActiveRecord::Base
  has_secure_password
  EMAIL_REGEX = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i 
  has_many :songs
  has_many :playlists, dependent: :destroy
  has_many :songs_liked, through: :play_lists, source: :song
  validates :name, :presence => true
  validates :alias, :presence => true
  validates :email, presence: true, uniqueness: { case_sensitive: false }, format: { with: EMAIL_REGEX }

  before_validation :downcase_email

  private
    def downcase_email
      self.email.downcase!
    end
end
